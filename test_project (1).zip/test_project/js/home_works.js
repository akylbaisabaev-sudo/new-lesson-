const gmailInput = document.querySelector('#gmail_input')
const gmailButton = document.querySelector('#gmail_button')
const gmailResult = document.querySelector('#gmail_result')

const gmailRegExp = /^[a-zA-Z0-9._]+@gmail\.com$/

gmailButton.onclick = () => {
    if (gmailRegExp.test(gmailInput.value)) {
        gmailResult.innerHTML = 'Всё верно'
        gmailResult.style.color = 'green'
    } else {
        gmailResult.innerHTML = 'Некорректный gmail'
        gmailResult.style.color = 'red'
    }
}

const childBlock = document.querySelector('.child_block')
const maxPosition = 449
let positionX = 0

const moveBlock = () => {
    if (positionX < maxPosition) {
        positionX++
        childBlock.style.left = `${positionX}px`
        requestAnimationFrame(moveBlock)
    }
}

moveBlock()
